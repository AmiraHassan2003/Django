from django.contrib import admin
from . models import Login

admin.site.register(Login)
# Register your models here.
