from django.shortcuts import render
from .models import UserInfo
from .forms import LoginForm
def signup(request):
    signup = UserInfo.objects.all()
    signupInfo = {"username" : signup[0].userName, "email" : signup[0].email}
    return render(request, 'Registration/signup.html', {'signup': signupInfo})



def login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            form.save()
    else: 
        form = LoginForm() 
    return render(request, 'Registration/login.html', {'loginF': form}) 


