from django.db import models

class UserInfo(models.Model):
    userName = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    password = models.CharField(max_length=50)


# Create your models here.
