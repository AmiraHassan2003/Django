from django.shortcuts import render
from .models import UserInfo

def signup(request):
    signup = UserInfo.objects.all()
    signupInfo = {"username" : signup[0].userName, "email" : signup[0].email}
    return render(request, 'Registration/signup.html', {'signup': signupInfo})

def login(request):
    login = UserInfo.objects.all()
    loginInfo = {"email" : login[0].email, "password" : login[0].password}
    return render(request, 'Registration/login.html', {'login': loginInfo})

