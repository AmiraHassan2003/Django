from django.db import models

class ContentAbout(models.Model):
    title = models.CharField(max_length=50)
    content = models.TextField()

class ContentHome(models.Model):
    title = models.CharField(max_length=50)
    content = models.TextField()
    
# Create your models here.
