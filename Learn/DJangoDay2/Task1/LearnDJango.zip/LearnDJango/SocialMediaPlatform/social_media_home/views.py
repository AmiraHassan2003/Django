from django.shortcuts import render
from django.http import HttpResponse
from .models import ContentAbout, ContentHome


# def home(request):
#     # return HttpResponse("Hello MerOooo")
#     return render(request, 'SocialMediaPlatform/index.html')


def home(request):
    home = ContentHome.objects.all()
    return render(request, 'social_media_home/index.html', {'homeInfo': home})

def about(request):
    about = ContentAbout.objects.all()
    return render(request, 'social_media_home/about.html', {'aboutInfo': about})